package com.infinite.java;

import java.io.IOException;
import java.util.List;

import javax.mail.FetchProfile.Item;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SearchServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // get the search parameters from the request
        String itemName = request.getParameter("itemName");
        String searchType = request.getParameter("searchType");
        
        // perform the search
        List<Item> searchResults = performSearch(itemName, searchType);
        
        // set the search results as a request attribute
        request.setAttribute("searchResults", searchResults);
        
        // forward to the search results page
        RequestDispatcher dispatcher = request.getRequestDispatcher("/searchResults.jsp");
        dispatcher.forward(request, response);
    }
    
    private List<Item> performSearch(String itemName, String searchType) {
		return null;
        // implement the search logic here
        // ...
    }
}

package com.infinite.java;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

public class Mobiledao {
	SessionFactory sessionFactory;
public List<Mobile> showMobile(){
		
		
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr=session.createCriteria(Mobile.class);
		
		List<Mobile> policyList=cr.list();
		
			return policyList;
		}
public Mobile searhByMobilebrand1(String Brand) {
    sessionFactory= SessionHelper.getConnection();
      Session session = sessionFactory.openSession();
      Criteria cr = session.createCriteria(Mobile.class);
      cr.add(Restrictions.eq("Mobilebrand", Brand));
    // cr.add(Restrictions.eq("policyId", policyId));
      List<Mobile> mobileList = cr.list();
      System.out.println(mobileList.size());
      return mobileList.get(0);
}

	
}

package com.infinite.java;

import java.io.IOException;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

@ManagedBean(name = "gdao")
@SessionScoped
public class Gadgetdao {

	public String selectedoption;

	public List<Gadges> gadList;
	public List<Gadges> mobileList;
	public List<Gadges> Refrigerator;

	public List<Gadges> getRefrigerator() {
		return Refrigerator;
	}

	public void setRefrigerator(List<Gadges> refrigerator) {
		Refrigerator = refrigerator;
	}

	public List<Gadges> getMobileList() {
		return mobileList;
	}

	public void setMobileList(List<Gadges> mobileList) {
		this.mobileList = mobileList;
	}

	public List<Gadges> getGadList() {
		return gadList;
	}

	public void setGadList(List<Gadges> gadList) {
		this.gadList = gadList;
	}

	public String getSelectedoption() {
		return selectedoption;
	}

	public void setSelectedoption(String selectedoption) {
		this.selectedoption = selectedoption;
	}

	SessionFactory sessionFactory;

	public Ordernew searchByItemname(String Itemname) {
		System.out.println(Itemname);
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Ordernew.class);
		Criterion criterion1 = Restrictions.eq("Itemname", Itemname);
//		Criterion criterion2 = Restrictions.eq("status", Status.PENDING);
		cr.add(Restrictions.and(criterion1));
		List<Ordernew> orderList = cr.list();
		if (orderList.size() == 0) {
			return null;
		}

		return orderList.get(0);
	}

	public List<Gadges> searchByCategory(String cat) {

		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Gadges.class);
		cr.add(Restrictions.eq("category", cat));
		return cr.list();

	}
	public List<Gadges> showCategory() {

		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Gadges.class);
//		cr.add(Restrictions.eq("category", cat));
		List<Gadges> list = cr.list();		
		return list;

	}


	

//	public String changeMethod() {
//		
//		
//		System.out.println(selectedoption);
//		String option=this.selectedoption;
//		
//		this.gadList=searchByCategory(option);
//		
//		return "showpage.xhtml?faces-redirect=true";
//		
//		
//	}
	public void mobilepage() {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Gadges.class);
		cr.add(Restrictions.eq("category", "mobile"));
		mobileList = cr.list();
		
		
		
	}
	public void Refrigerator() {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Gadges.class);
		cr.add(Restrictions.eq("category", "Refrigerator"));
		mobileList = cr.list();
		
	}

	public void changeEvent(ValueChangeEvent e) {

		System.out.println("guigduiwhgdiugqafduigqwiudgquiwfgeiuwqd");
		System.out.println(this.selectedoption);

		selectedoption = e.getNewValue().toString();
		String option = this.selectedoption;
		this.gadList = searchByCategory(option);
		rediectTo();

	}

	public String rediectTo() {

		return "showpage.xhtml";
	}

	public void handleChange() throws IOException {

		System.out.println("ajax event triggered.........");
		String option = this.selectedoption;
		System.out.println("option   " + option);
		this.gadList = searchByCategory(option);

		System.out.println(gadList);

		FacesContext.getCurrentInstance().getExternalContext().redirect("showpage.xhtml");
		FacesContext.getCurrentInstance().responseComplete();

	}
	public String addMobile(Mobile mobile) {
		SessionHelper sh = new SessionHelper();
		SessionFactory sf = sh.getConnection();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		Criteria cr = session.createCriteria(Mobile.class);
		session.save(mobile);
		tran.commit();
		session.close();
		return "add Record";
	}

}

package com.infinite.java;

import java.util.ArrayList;
import java.util.List;

public class test {
     public static void main(String[] args) {
//		Customer customer=new Customer();
//		customer.setFirstname("Saihithi");
//		customer.setPassword("Shyam62@123");
//		customer.setConfirmpassword("Shyam62@123");
//		
//		Customerdao customerdao=new Customerdao();
//		System.out.println(customerdao.forgotpassword(customer));
//		
		
		
		System.out.println(new Stockdao().searchStock1("vivot1", "dswe", "100-1000"));
		
		 	
		

		
	}
	
	
	
	
	

}

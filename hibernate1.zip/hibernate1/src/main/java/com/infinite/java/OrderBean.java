package com.infinite.java;

import java.io.Serializable;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;


@ManagedBean(name="OrderBean")
@SessionScoped
public class OrderBean {
	private String customerName;
	private String customerId;
	private String adress;
	private String phoneNumber;
	private String email;
	private String itemname;
	private String oid;
	private double price;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void setOrderDetails(Order order) {
		   this.currentOrder = order;
		}
	private static final long serialVersionUID = 1L;
	   
	   private Order currentOrder;
	   
	   public Order getCurrentOrder() {
	      return currentOrder;
	   }
	   
	   public void setCurrentOrder(Order currentOrder) {
	      this.currentOrder = currentOrder;
	   }
	   public OrderBean(String customerName, String customerId, String adress, String phoneNumber, String email,
			String itemname, String oid, double price, Order currentOrder) {
		super();
		this.customerName = customerName;
		this.customerId = customerId;
		this.adress = adress;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.itemname = itemname;
		this.oid = oid;
		this.price = price;
		this.currentOrder = currentOrder;
	}
	public OrderBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String confirmOrder() {
			// Here you can implement the logic to save the order details to the database or some other storage
			// For example:
			// OrderDAO.saveOrderDetails(orderDetails);
			// And then return the outcome for the next page
			return "order-confirmation";
		}
	   public String showConfirmation() {
		    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Order confirmed!"));
		    return "Show.xhtml"; // name of the confirmation page
		}
	   public String setOrderDetails1(Order order) {
		  
			// set order details
			return "confirm";
		}



	
	
}

package com.infinite.java;

import java.util.ArrayList;
import java.util.List;

public class Order {

    private List<Order> orders;
    private Order currentOrder; // Declare currentOrder variable

    public Order() {
        orders = new ArrayList<Order>();
    }

    public void addOrder(Order order) {
        orders.add(order);
    }

    public List<Order> Showorder() {
        return orders;
    }
    
    // Set the currentOrder object
    public void setCurrentOrder(Order order) {
        this.currentOrder = order;
    }
    
    // Get the currentOrder object
    public Order getCurrentOrder() {
        return currentOrder;
    }
}

package com.infinite.java;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;

@ManagedBean(name="Stockdao")
public class Stockdao {
	SessionFactory sessionFactory;
	private String Generateid() {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Stockdetails.class);
		List<Stockdetails> stockdetailsList = cr.list();
		session.close();
		if (stockdetailsList.size() == 0) {
			System.out.println("List Checked");
			return "S001";
		} else {
			String id = stockdetailsList.get(stockdetailsList.size() - 1).getStockid();
			int id1 = Integer.parseInt(id.substring(1));
			id1++;
			String id2 = String.format("S%03d", id1);

			return id2;
		}
	}
	
	public Stockdetails searchStock(String stockid) {
	sessionFactory = SessionHelper.getConnection();
		 Session session = sessionFactory.openSession();
 Criteria cr = session.createCriteria(Stockdetails.class);
		 cr.add(Restrictions.eq("stockid",stockid));
		List<Stockdetails> itemList=cr.list();
		if (!itemList.isEmpty()) {
	        return itemList.get(0);
	    } else {
	        return null; // or throw an exception, depending on your requirements
	    }
	}
	
	public int searchitem(String stockname){

		sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Criteria cr = session.createCriteria(Stockdetails.class);
        cr.add(Restrictions.eq("itemName",stockname));
       List<Customer> itemList=cr.list();
        return itemList.size();
        }
	
	public List<Stockdetails> ShowStock(String itemname) {
	    sessionFactory = SessionHelper.getConnection();
	    Session session = sessionFactory.openSession();
	    Criteria cr = session.createCriteria(Stockdetails.class);
	    cr.add(Restrictions.eq("itemname", itemname));
	  
	    List<Stockdetails> stockdetailsList = cr.list();
	    return stockdetailsList;
	}


	public List<Integer> quantity(String stockid) {
		 sessionFactory = SessionHelper.getConnection();
		 Session session = sessionFactory.openSession();
		 Criteria cr = session.createCriteria(Stockdetails.class);
		 cr.add(Restrictions.eq("stockid",stockid));
		 List<Stockdetails> stockdetailsList = cr.list();
//		 int len=stockdetailsList.get(0).getQuantity();
		 List<Integer>list=new ArrayList<Integer>();
		 if (!stockdetailsList.isEmpty()) {
		        int length = stockdetailsList.get(0).getQuantity();
		 for(int i=1;i<=length;i++ ) {
			 list.add(i);
			}
		 }
		 return list;
		 }
	
	
	
	
//	public List<Stockdetails> searchStock1(String itemName) {
//	    sessionFactory = SessionHelper.getConnection();
//	    Session session = sessionFactory.openSession();
//	    Criteria cr = session.createCriteria(Stockdetails.class);
//	    if (itemName != null && !itemName.isEmpty()) {	    
//	     cr.add(Restrictions.like("itemname", "%" + itemName + "%"));
//	    }
//	    cr.addOrder(Order.asc("id")); // order the results by ID in ascending order
//	    List<Stockdetails> lst = cr.list();
//	    return lst;
//	}
	
	

	
	
	public List<Stockdetails> searchStock1(String itemname, String searchType, String priceRange) {
		 System.out.println("itemName: " + itemname);
	    sessionFactory = SessionHelper.getConnection();
	    Session session = sessionFactory.openSession();
	    Criteria cr = session.createCriteria(Stockdetails.class);
	    if (itemname != null && !itemname.isEmpty()) {
	        if (searchType.equals("full")) {
	            cr.add(Restrictions.eq("Itemname", itemname));
	        } else if (searchType.equals("first")) {
	            cr.add(Restrictions.like("Itemname", itemname + "%"));
	        }
	    }
	    if (priceRange != null && !priceRange.isEmpty()) {
	        String[] prices = priceRange.split("-");
	        cr.add(Restrictions.between("price", String.valueOf(Integer.parseInt(prices[0])), String.valueOf(Integer.parseInt(prices[1]))));

	    }
    cr.addOrder(Order.asc("id"));
	    List<Stockdetails> lst = cr.list();
	    
	    
	    return lst;
	  
	}

	
	
	
//	public List<Stockdetails> searchStock1(String Itemname,String searchType) {
//	    sessionFactory = SessionHelper.getConnection();
//    Session session = sessionFactory.openSession();
//   Criteria cr = session.createCriteria(Stockdetails.class);
//	    if (Itemname != null && !Itemname.isEmpty()) {
//	        cr.add(Restrictions.like("itemname", Itemname + "%"));
//	    }
//	    cr.addOrder(Order.asc("id")); // order the results by ID in ascending order
//	    List<Stockdetails> lst = cr.list();
// 
//	return lst;
//	}


	

}




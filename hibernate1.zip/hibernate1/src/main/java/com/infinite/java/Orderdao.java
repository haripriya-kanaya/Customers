package com.infinite.java;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
@ManagedBean(name="Orderdao")
@SessionScoped
public class Orderdao {
	private String OdrIDs;
	SessionFactory sessionFactory;
	private boolean orderConfirmed;
	public String orderIdGen() {
	    sessionFactory = SessionHelper.getConnection();
	    Session session = sessionFactory.openSession();
	    Criteria cr = session.createCriteria(Ordernew.class);
	    List<Ordernew> orderList = cr.list();
	    if(orderList.size()==0) {
	    	return "O001";
	    }else {
	    	int id = Integer.parseInt(orderList.get(orderList.size()-1).getOrderId().substring(1));
	    	String Oid = String.format("O%03d",++id);
	    	return Oid;
	    }
	    
	    	
	    }
	public double calcprice(String firstname) {
   	 sessionFactory = SessionHelper.getConnection();
	    Session session = sessionFactory.openSession();

    	Query query=session.createQuery("select sum(Price) from Ordernew where firstname=:firstname").setParameter("firstname", firstname);
    	 List<Double> count =query.list();
    	 Double b = (Double)count.get(0);
    	 if(b==null) {
    		 return 0;
    	 }
    	 session.close();
    	 
	    
		return count.get(0);
	}
	
	
	public String addOrder(Ordernew ordernew, String custId) {
		Customer customer = new Customer();
		 String id1 = customer.getId();
		SessionHelper sh = new SessionHelper();
		SessionFactory sf = sh.getConnection();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		Criteria cr = session.createCriteria(Ordernew.class);
		String id=orderIdGen();
		ordernew.setOrderId(id);
		ordernew.setCustomerID(custId);
		OdrIDs=id;
		System.out.println("Cust Id is"+custId);
		double newprice = ordernew.getQuantity() * ordernew.getPrice();
		double deliverycharge = (newprice <= 30000) ? 100.0 : 0.0;
		double gst = 0.05;
		double gstAmount = newprice * gst;
		double totalprice = newprice + gstAmount + deliverycharge;
		ordernew.setPrice(totalprice);
       session.save(ordernew);
		tran.commit();
		session.close();
		System.out.println(OdrIDs);
		 return"Showorder.xhtml?faces-redirect=true";
		}
	
	
//	public boolean confirmOrder(Order order) {
//	    // perform necessary actions to confirm the order, e.g. update order status in database
//	    
//	    // set orderConfirmed flag to true
//	    this.orderConfirmed = true;
//	    
//	    return true;
//	}

	
	
	
	
	
	

	
	/*
	 * public Order getOrderDetails(String firstname) { sessionFactory =
	 * SessionHelper.getConnection(); Session session =
	 * sessionFactory.openSession(); Criteria cr =
	 * session.createCriteria(Order.class); cr.add(Restrictions.eq("firstname",
	 * firstname)); Order order = (Order) cr.uniqueResult(); if (order == null) {
	 * FacesMessage message = new FacesMessage("No Records Found For This User");
	 * FacesContext.getCurrentInstance().addMessage(null, message); return null; }
	 * return order; }
	 */
	public List<Ordernew> Showorder( double Price) {
	    sessionFactory = SessionHelper.getConnection();
	    Session session = sessionFactory.openSession();
	    Criteria cr = session.createCriteria(Ordernew.class);
//	    cr.add(Restrictions.eq("orderId", OdrIDs));
	    cr.add(Restrictions.eq("price", Price));
	    
	    List<Ordernew> ordernewList = cr.list();
	    System.out.println("gau");
	    return ordernewList;
	}






}
	

	
package com.infinite.java;



import java.util.Date;


import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;


@ManagedBean(name="Customer")
@SessionScoped
@Entity


@Table(name="customers")
public class Customer   {
	
	 @Id
	   
	@Column(name="id")
	private String id;
	 
	
	
	@Column(name="confirmpassword")
	private String confirmpassword;
	
	@Column(name="firstname")
	private String firstname;
	
	@Column(name="lastname")
	private String Lastname;
	
	@Column(name="password")
	private String password;
	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String id, String confirmpassword, String firstname, String lastname, String password, String email,
			String phone, String adress, Date dob, String password2, String gender, String lastpassword) {
		super();
		this.id = id;
		this.confirmpassword = confirmpassword;
		this.firstname = firstname;
		Lastname = lastname;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.adress = adress;
		this.dob = dob;
		this.password2 = password2;
		this.gender = gender;
		this.lastpassword = lastpassword;
	}

	@Column(name="email")
	private String email;
	
	@Column(name="phone")
	private String phone;
	
	@Column(name="address")
	private String adress;
	
	@Column(name="dob")
	private Date dob;
	private String password2;
	
	


	public String getPassword2() {
		return password2;
	}

	public void setPassword2(String password2) {
		this.password2 = password2;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	@Column(name="gender")
	private String gender;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return Lastname;
	}

	public void setLastname(String lastname) {
		Lastname = lastname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}



	public String getGender() {
		return gender;
	}
	

	public void setGender(String gender) {
		this.gender = gender;
	}
	private String lastpassword;




	public String getLastpassword() {
		return lastpassword;
	}

	public void setLastpassword(String lastpassword) {
		this.lastpassword = lastpassword;
	}
	
	}
	






	


package com.infinite.java;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@ManagedBean(name="Ordernew")
@SessionScoped
@Entity

@Table(name="ordertable")
public class Ordernew {
	@Id
	@Column(name="orderId")
	private String orderId;

	
	
	@Column(name="CustomerId")
	private String customerID;
	
	
	@Column(name="Itemname")
	private String Itemname;
	@Column(name="price")
	private  double Price;
	@Column(name="Quantity")
	private double Quantity;
	public String getOrderId() {
		return orderId;
	}
	
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	
	public String getItemname() {
		return Itemname;
	}

	public void setItemname(String itemname) {
		Itemname = itemname;
	}

	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public double getQuantity() {
		return Quantity;
	}
	public void setQuantity(double quantity) {
		Quantity = quantity;
	}
	public Ordernew(String orderId, String customerID, String itemname, double price, double quantity) {
		super();
		this.orderId = orderId;
		this.customerID = customerID;
		Itemname = itemname;
		Price = price;
		Quantity = quantity;
	}
	public Ordernew() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}

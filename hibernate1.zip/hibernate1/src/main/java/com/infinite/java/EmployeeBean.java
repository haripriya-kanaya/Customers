package com.infinite.java;

import javax.annotation.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class EmployeeBean {
	private String Itemname;
	private double price;
	private double Quantity;
	private int Deliverycharge;
	private int Gst;
	private String Confirmorder;
	public String getItemname() {
		System.out.println("getItemname Method:"+this.Itemname);
		return Itemname;
	}
	public void setItemname(String itemname) {
		System.out.println("setItemname Method : old value"+this.Itemname +"new value:"+Itemname );
		Itemname = itemname;
	}
	public double getPrice() {
		System.out.println("getPrice Method:"+this.price);
		return price;
	}
	public void setPrice(double price) {
		System.out.println("setPrice Method : old value"+this.price +"new value:"+price );
	
		this.price = price;
	}
	public double getQuantity() {
		System.out.println("getQuantity Method:"+this.Quantity);
		
		return Quantity;
	}
	public void setQuantity(double quantity) {
		System.out.println("setQuantity Method : old value"+this.Quantity +"new value:"+quantity );
		Quantity = quantity;
	}
	public int getDeliverycharge() {
		System.out.println("getDeliverycharge Method:"+this.Deliverycharge);
		return Deliverycharge;
	}
	public void setDeliverycharge(int deliverycharge) {
		System.out.println("setDeliverycharge Method : old value"+this.Deliverycharge +"new value:"+deliverycharge );
		Deliverycharge = deliverycharge;
	}
	public int getGst() {
		System.out.println("getGst Method:"+this.Gst);
		return Gst;
	}
	public void setGst(int gst) {
		System.out.println("setGst Method : old value"+this.Gst +"new value:"+gst );
		Gst = gst;
	}
	public String getConfirmorder() {
		System.out.println("getConfirmorder :"+this.Confirmorder);
		return Confirmorder;
	}
	public void setConfirmorder(String confirmorder) {
		System.out.println("setConfirmorder Method : old value"+this.Confirmorder +"new value:"+confirmorder );
		Confirmorder = confirmorder;
	}
	
	

}

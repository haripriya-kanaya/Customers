package com.infinite.java;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@ManagedBean(name="Stockdetails")
@SessionScoped
@Entity

@Table(name="stock")
public class Stockdetails {
	
	
	@Id

	@Column(name="stockid")
	
	
private String stockid;
	@Override
	public String toString() {
		return "Stockdetails [stockid=" + stockid + ", id=" + id + ", itemname=" + itemname + ", price=" + price
				+ ", quantity=" + quantity + "]";
	}
	public Stockdetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Stockdetails(String stockid, String id, String itemname, String price, int quantity) {
		super();
		this.stockid = stockid;
		this.id = id;
		this.itemname = itemname;
		this.price = price;
		this.quantity = quantity;
	}
	@Column(name="id")
	private String id;
	
	
	@Column(name="itemname")
	
private String itemname;
	@Column(name="price")
private String price;
	@Column(name="quantity")
	private int quantity;
	



public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
public String getStockid() {
	return stockid;
}
public void setStockid(String stockid) {
	this.stockid = stockid;
}
public String getItemname() {
	return itemname;
}
public void setItemname(String itemname) {
	this.itemname = itemname;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}



}

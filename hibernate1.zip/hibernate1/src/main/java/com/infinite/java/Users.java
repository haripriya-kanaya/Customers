package com.infinite.java;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@ManagedBean
@SessionScoped
@Entity
@Table(name="customers1")
public class Users {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="name")
	private String name ;
	
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Column(name="password")
	private String password;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Users [name=" + name + ", password=" + password + "]";
	}
	public Users(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}
}
	
	
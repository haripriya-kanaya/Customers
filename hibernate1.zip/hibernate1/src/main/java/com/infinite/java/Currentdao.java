package com.infinite.java;

import java.io.Serializable;

import javax.annotation.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(value = "Currentdao")
@SessionScoped
public class Currentdao implements Serializable {
    private Order currentOrder;

    // getter and setter for currentOrder

    public String confirmOrder() {
        // code to confirm order and set currentOrder
        return "success";
    }
}

package com.infinite.java;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;

import org.hibernate.Transaction;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

@ManagedBean(name = "Customerdao")
@SessionScoped
public class Customerdao {
	SessionFactory sessionFactory;
	private Customer c;

	public Customer getC() {
		return c;
	}

	public void setC(Customer c) {
		this.c = c;
	}

	public String checkUsers(Customer customer) {
		Map sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Customer.class);
		cr.add(Restrictions.eq("firstname", customer.getFirstname()));
		cr.add(Restrictions.eq("password", customer.getPassword()));

		/*
		 * System.out.println(user.getName()); System.out.println(user.getPassword());
		 */
		List<Customer> coml = cr.list();
		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext externalContext = context.getExternalContext();
		if (coml.size() == 1) {
			externalContext.getSessionMap().put("firstname", customer.getFirstname());

			System.out.println("Login Success");

			Customer cust = searchBySignupName(customer.getFirstname(), customer.getPassword());
			System.out.println("Name is cust Variable" + cust.getFirstname());
			System.out.println("Id in  cust" + cust.getId());
			// System.out.println(c);
			// sessionMap.put("SignupUserId", p.getSignupUserId());
			sessionMap.put("UserInfo", cust);
			c = cust;
			externalContext.getSessionMap().put("CustId", customer.getId());

			// return "Showstock.jsp";

			return "Navbar1.xhtml";
		} else {
			context.addMessage("formclass:p", new FacesMessage("Invalid Credentials"));
			return null;

		}
	}

	public String addCustomer(Customer customer) throws NoSuchAlgorithmException {
		System.out.println(customer);
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		FacesContext context = FacesContext.getCurrentInstance();
		// ExternalContext externalContext=context.getExternalContext();
		/*
		 * boolean validUser = isValidUser(((Customer) customer).getFirstname()); if
		 * (validUser == true) { context.addMessage("cregfrm:Name", new
		 * FacesMessage("Name already exists..")); return null; }
		 */

		String id = Generateid();
		System.out.println("Generated Id is" + id);
		customer.setId(id);
		customer.setConfirmpassword(customer.getPassword());
		customer.setLastpassword(customer.getPassword());
	customer.setPassword2(customer.getPassword());
		Criteria cr = session.createCriteria(Customer.class);
		org.hibernate.Transaction tran = session.beginTransaction();
		session.save(customer);
		tran.commit();
		System.out.println("Saved");

		context.addMessage("cregfrm:name", new FacesMessage("Details saved sucessfully.."));
		return "Thanks.xhtml";

	}

	private String Generateid() {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Customer.class);
		List<Customer> customerList = cr.list();
		session.close();
		if (customerList.size() == 0) {
			System.out.println("List Checked");
			return "C001";
		} else {
			String id = customerList.get(customerList.size() - 1).getId();
			int id1 = Integer.parseInt(id.substring(1));
			id1++;
			String id2 = String.format("C%03d", id1);

			return id2;
		}
	}

	public void validateName(FacesContext context, UIComponent comp, Object value) {
		String mno = (String) value;
		String pattern = "(?=.*[a-z])(?=.*[A-Z])";
		boolean result = mno.matches(pattern);
		if (result == false) {
			((UIInput) comp).setValid(false);

			FacesMessage message = new FacesMessage("Enter Only characters");
			context.addMessage(comp.getClientId(context), message);
		}

	}

	public void validatePhnNo(FacesContext context, UIComponent comp, Object value) {

		System.out.println("inside validate method");

		String mno = (String) value;
		boolean flag = false;
		if (mno.matches("\\d{10}")) {
			flag = true;
		}

		if (flag == false) {
			((UIInput) comp).setValid(false);

			FacesMessage message = new FacesMessage("invalid PhnNo");
			context.addMessage(comp.getClientId(context), message);
		}

	}

	public void validatePassword(FacesContext context, UIComponent comp, Object value) {

//	System.out.println("inside validate method");

		String mno = (String) value;
		String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
		boolean result = mno.matches(pattern);
		if (result == false) {
			((UIInput) comp).setValid(false);

			FacesMessage message = new FacesMessage(
					"invalid Password..... (Take password with 1 capital letter,1 special letter,length min 8 as Ex:Hrwsg@123)");
			context.addMessage(comp.getClientId(context), message);
		}

	}

	public void validateEmail(FacesContext context, UIComponent comp, Object value) {
		String email = (String) value;
		Pattern pattern = Pattern.compile("^[a-zA-Z][a-zA-Z0-9]{7,}@gmail.com");
		Matcher matcher = pattern.matcher(email);
		if (!matcher.matches()) {
			((UIInput) comp).setValid(false);
			FacesMessage message = new FacesMessage("Invalid email address format");
			context.addMessage(comp.getClientId(context), message);
		}
	}

	private boolean isValidUser(String name) {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Customer.class);
		cr.add(Restrictions.eq("name", name));
		List<Customer> listcustomer = cr.list();
		if (listcustomer.size() == 1) {
			return true;
		}
		// TODO Auto-generated method stub
		return false;
	}

	public Customer search(String firstname) {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.add(Restrictions.eq("firstname", firstname));
		List<Customer> customerList = criteria.list();
		// int count = customerList.size();
		return customerList.get(0);

	}

	public int searchfirstname(String firstname) {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Customer.class);
		cr.add(Restrictions.eq("firstname", firstname));
		List<Customer> listcustomer = cr.list();
		int count = listcustomer.size();
		System.out.println(count);
		return count;

	}


	public Customer searchCustomer(String id) {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Customer.class);
		cr.add(Restrictions.eq("id", id));
		List<Customer> itemList = cr.list();
		return itemList.get(0);
	}

	
	
	

	// ...

//	    // Function to retrieve the customer from the database based on the provided username
//	    public Customer getCustomerByfirstname(String firstname) {
//			return c;
//	        // Implementation of the function to retrieve the customer from the database based on the username
//	    }
//
//	    public String forgotpassword(Customer customer) {
//	        // Retrieve the customer's last three password hashes from the database
//	        List<String> passwordHistory = getPasswordHistory(customer.getFirstname());
//
//	        // Hash the new password entered by the user
//	        String newPasswordHash = hashPassword(customer.getPassword());
//
//	        // Check if the new password matches any of the previous three passwords
//	        if (passwordHistory.contains(newPasswordHash)) {
//	            FacesMessage errorMessage = new FacesMessage("Your new password cannot be the same as any of your previous three passwords. Please choose a different password.");
//	            errorMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
//	            FacesContext.getCurrentInstance().addMessage("formclass:password", errorMessage);
//	            return null;
//	        }
//
//	        // Hash the confirm password entered by the user
//	        String confirmNewPasswordHash = hashPassword(customer.getConfirmpassword());
//
//	        // Check if the new password and confirm password match
//	        if (!newPasswordHash.equals(confirmNewPasswordHash)) {
//	            FacesMessage errorMessage = new FacesMessage("New password and confirm password do not match. Please try again.");
//	            errorMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
//	            FacesContext.getCurrentInstance().addMessage("formclass:confirmPassword", errorMessage);
//	            return null;
//	        }
//
//	        // Update the customer's password in the database
//	        updatePassword(customer.getFirstname(), newPasswordHash);
//
//	        // Redirect to the login page
//	        return "login.xhtml?faces-redirect=true";
//	    }
//
//	    // Function to retrieve the customer's last three password hashes from the database
//	    private List<String> getPasswordHistory(String firstname) {
//			return getPasswordHistory(null);
//	        // Implementation of the function to retrieve the password history from the database
//	    }
//
//	    // Function to hash the password using a secure one-way hashing algorithm
//	    private String hashPassword(String password) {
//			return password;
//	        // Implementation of the hashing algorithm
//	    }
//
//	    // Function to update the customer's password in the database
//	    private void updatePassword(String firstname, String newPasswordHash) {
//	        // Implementation of the function to update the password in the database
//	    }


	
	
	public String forgotpassword(Customer customer) {

		if (customer == null) {
			// Create a new instance of the Customer class and initialize it with the
			// required values
			customer = new Customer();
			customer.setFirstname("Default FirstName");
			customer.setLastname("Default LastName");
			// ...
		}

		FacesContext context = FacesContext.getCurrentInstance();

		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		int count = searchfirstname(customer.getFirstname());
		System.out.println(count);
		if (count == 1) {
			Customer cust = search(customer.getFirstname());
			System.out.println(cust.getFirstname());
			customer.setId(cust.getId());
			customer.setEmail(cust.getEmail());
			customer.setPhone(cust.getPhone());
			customer.setAdress(cust.getAdress());
			customer.setDob(cust.getDob());
			customer.setFirstname(cust.getFirstname());
			String cs1 = customer.getPassword();//new pss
			String cs2 = customer.getLastpassword();
			String cs3 = customer.getPassword2();
			
			String css1 = cust.getPassword();
			String css2 = cust.getLastpassword();
			String css3 = cust.getPassword2();
			
			System.out.println(cs1);
			System.out.println(cs2);
			System.out.println(cs3);
			System.out.println(css1);
			System.out.println(css2);
			System.out.println(css3);
			
			
			// Check if the new password matches any of the customer's previous three
			// passwords
			// use &&
			if (!cs1.equals(css1)
					
					&& !cs1.equals(css2)
					&& !cs1.equals(css3)) {
				
//				  context.addMessage("formclass:password", new
//				  FacesMessage("New password must not match previous 3 passwords"));
				 
				customer.setPassword2(cust.getLastpassword());
				customer.setLastpassword(cust.getConfirmpassword());
				customer.setPassword(customer.getPassword());
				
				Transaction transaction = session.beginTransaction();
				session.update(customer); // update the customer object
				transaction.commit();
				session.close();
				System.out.println("not matched");
			
			} else {
				 context.addMessage("formclass:password", new FacesMessage("New password must not match previous 3 passwords"));
		            return null;

				
//				context.addMessage("formclass:password", new FacesMessage("Password does not match previous 3 passwords"));
//				return "login.xhtml?faces-redirect=true";
			}

			// Check if the new password matches the "confirm password" field
			/*
			 * if (!customer.getPassword().equals(customer.getPassword2())) {
			 * 
			 * context.addMessage("formclass:password2", new
			 * FacesMessage("Passwords do not match"));
			 * 
			 * }
			 */
			// Update the customer's password and last name fields

		} else {
		    System.out.println("password does not match");
		   
		}
		return null;

		}
		
	

	public String getfirstname(String firstname) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Customer customer = (Customer) session.get(Customer.class, firstname);
		session.close();
		return customer.getFirstname();
	}

	public class InvalidPasswordException extends Exception {
		public InvalidPasswordException(String message) {
			super(message);
		}
	}

//	public void updatePassword(Customer customer, String newPassword) throws InvalidPasswordException {
//	    List<PasswordHistory> passwordHistoryList = customer.getPasswordHistoryList();
//
//	    // check if new password matches any of the last three passwords
//	    for (PasswordHistory passwordHistory : passwordHistoryList) {
//	        if (newPassword.equals(passwordHistory.getPassword())) {
//	            throw new InvalidPasswordException("Password cannot be the same as any of the last three passwords");
//	        }
//	    }
//
//	    // create a new PasswordHistory entity and add it to the customer's password history list
//	    PasswordHistory newPasswordHistory = new PasswordHistory();
//	    newPasswordHistory.setCustomer(customer);
//	    newPasswordHistory.setPassword(newPassword);
//	    newPasswordHistory.setChangeDate(new Date());
//	    PasswordHistory.add(newPasswordHistory);
//
//	    // remove any PasswordHistory entities that are more than three changes old
//	    if (passwordHistoryList.size() > 3) {
//	        passwordHistoryList.remove(0);
//	    }
//
//	    // update the customer entity with the new password
//	    customer.setPassword(newPassword);
//	    sessionFactory.getCurrentSession().update(customer);
//	}

	public Customer searchBySignupName(String firstname, String password) {
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Customer.class);
		cr.add(Restrictions.eq("firstname", firstname));
		cr.add(Restrictions.eq("password", password));
		System.out.println("In Search Method");
		Customer Cus = (Customer) cr.uniqueResult();
		return Cus;
	}

}
